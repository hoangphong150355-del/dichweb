# Dịch Web – app trình duyệt dịch cho Android

Trình duyệt nhỏ (WebView) có sẵn nút dịch trang sang **English / 中文 / Tiếng Việt**.
Dịch bằng Google Translate (miễn phí) hoặc Gemini API (nhập key trong ⚙). Gemini lỗi thì tự chuyển sang Google.

## Cách 1: build APK bằng GitHub (không cần cài gì)
1. Tạo repo mới trên github.com (để private cũng được).
2. Upload toàn bộ nội dung thư mục này lên repo, nhớ cả thư mục ẩn `.github`.
   Nếu kéo thả không lên `.github`: chọn *Add file → Create new file*, gõ tên `.github/workflows/build.yml` rồi dán nội dung file đó vào.
3. Vào tab **Actions** → chọn **Build APK** → **Run workflow** (hoặc tự chạy sau khi upload).
4. Chờ khoảng 3–5 phút, bấm vào lần chạy xong → mục **Artifacts** → tải `DichWeb-apk`.
5. Giải nén, chép `app-debug.apk` vào điện thoại và cài (cho phép cài từ nguồn không rõ nếu máy hỏi).

## Cách 2: Android Studio
Mở thư mục này bằng Android Studio → *Build → Build APK(s)*.

## Cách dùng
- Gõ địa chỉ hoặc từ khóa ở thanh trên rồi bấm **Đi**.
- Bấm **EN / 中文 / VI** để dịch trang. Sang trang mới app tự dịch tiếp.
- Bấm **Gốc** để tắt dịch và hiện bản gốc.
- Bấm **⚙** để chọn Gemini API, nhập key, chọn model, thử kết nối.
- Mở link từ app khác (Zalo, Chrome…) cũng có thể chọn "Dịch Web" để mở.
