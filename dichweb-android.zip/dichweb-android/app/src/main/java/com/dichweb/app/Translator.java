package com.dichweb.app;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Gọi Google Translate (miễn phí) hoặc Gemini API. Gemini lỗi thì tự dùng Google. */
class Translator {
    static final String DEFAULT_MODEL = "gemini-2.5-flash";

    static class HttpException extends IOException {
        final int code;

        HttpException(int code, String body) {
            super("HTTP " + code + detail(body));
            this.code = code;
        }

        private static String detail(String body) {
            try {
                return ": " + new JSONObject(body).getJSONObject("error").getString("message");
            } catch (Exception e) {
                return "";
            }
        }
    }

    private final SharedPreferences prefs;
    private final ExecutorService textPool = Executors.newFixedThreadPool(6);
    private final Map<String, String> cache = Collections.synchronizedMap(
            new LinkedHashMap<String, String>(256, 0.75f, false) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                    return size() > 4000;
                }
            });

    Translator(SharedPreferences prefs) {
        this.prefs = prefs;
    }

    static String langName(String code) {
        if ("zh-CN".equals(code)) return "Simplified Chinese";
        if ("vi".equals(code)) return "Vietnamese";
        return "English";
    }

    /** Trả về mảng bản dịch cùng độ dài với texts; phần tử null nếu dịch lỗi. */
    String[] translate(String[] texts, String tl) {
        String[] res = new String[texts.length];
        String engine = prefs.getString("engine", "google");
        String key = prefs.getString("apiKey", "").trim();
        String model = prefs.getString("model", DEFAULT_MODEL).trim();
        if (model.isEmpty()) model = DEFAULT_MODEL;

        if ("gemini".equals(engine) && !key.isEmpty()) {
            List<Integer> todo = new ArrayList<>();
            for (int i = 0; i < texts.length; i++) {
                String hit = cache.get("m|" + model + "|" + tl + "|" + texts[i]);
                if (hit != null) res[i] = hit;
                else todo.add(i);
            }
            if (!todo.isEmpty()) {
                try {
                    String[] in = new String[todo.size()];
                    for (int k = 0; k < in.length; k++) in[k] = texts[todo.get(k)];
                    String[] out = gemini(in, tl, key, model);
                    for (int k = 0; k < out.length; k++) {
                        res[todo.get(k)] = out[k];
                        cache.put("m|" + model + "|" + tl + "|" + in[k], out[k]);
                    }
                } catch (Exception e) {
                    // Gemini lỗi (hết lượt, mạng...) -> dùng Google Translate bên dưới
                }
            }
        }

        List<Integer> rest = new ArrayList<>();
        for (int i = 0; i < texts.length; i++) {
            if (res[i] == null) rest.add(i);
        }
        if (!rest.isEmpty()) google(texts, tl, res, rest);
        return res;
    }

    String testGemini(String key, String model) throws Exception {
        if (model == null || model.trim().isEmpty()) model = DEFAULT_MODEL;
        return gemini(new String[]{"Hello, how are you today?"}, "vi", key.trim(), model.trim())[0];
    }

    // ---- Google Translate (không cần key) ----

    private void google(final String[] texts, final String tl, final String[] res, List<Integer> idx) {
        List<Future<?>> futures = new ArrayList<>();
        for (Integer boxed : idx) {
            final int i = boxed;
            futures.add(textPool.submit(() -> {
                res[i] = googleOne(texts[i], tl);
            }));
        }
        for (Future<?> f : futures) {
            try {
                f.get();
            } catch (Exception ignored) {
            }
        }
    }

    private String googleOne(String text, String tl) {
        String cacheKey = "g|" + tl + "|" + text;
        String hit = cache.get(cacheKey);
        if (hit != null) return hit;
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl="
                        + URLEncoder.encode(tl, "UTF-8") + "&dt=t";
                String body = "q=" + URLEncoder.encode(text, "UTF-8");
                String resp = http(url, "application/x-www-form-urlencoded;charset=UTF-8", body, null);
                JSONArray segs = new JSONArray(resp).getJSONArray(0);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < segs.length(); i++) {
                    JSONArray seg = segs.optJSONArray(i);
                    if (seg != null) sb.append(seg.optString(0, ""));
                }
                String out = sb.toString();
                cache.put(cacheKey, out);
                return out;
            } catch (Exception e) {
                try {
                    Thread.sleep(400L * (attempt + 1));
                } catch (InterruptedException ie) {
                    return null;
                }
            }
        }
        return null;
    }

    // ---- Gemini API ----

    private String[] gemini(String[] texts, String tl, String key, String model) throws Exception {
        String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                + URLEncoder.encode(model, "UTF-8") + ":generateContent";

        JSONArray arr = new JSONArray();
        for (String t : texts) arr.put(t);
        String prompt = "Translate every string in the JSON array below into " + langName(tl)
                + ". Keep the meaning, tone and proper nouns natural; do not add explanations. "
                + "Return a JSON array of strings with exactly the same length and order.\n\n"
                + arr.toString();

        JSONObject part = new JSONObject().put("text", prompt);
        JSONObject content = new JSONObject().put("parts", new JSONArray().put(part));
        JSONObject schema = new JSONObject()
                .put("type", "ARRAY")
                .put("items", new JSONObject().put("type", "STRING"));
        JSONObject config = new JSONObject()
                .put("temperature", 0.2)
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema);
        JSONObject body = new JSONObject()
                .put("contents", new JSONArray().put(content))
                .put("generationConfig", config);

        for (int attempt = 0; ; attempt++) {
            try {
                String resp = http(url, "application/json", body.toString(), key);
                JSONArray parts = new JSONObject(resp)
                        .getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
                JSONArray out = new JSONArray(sb.toString());
                if (out.length() != texts.length) throw new IOException("Gemini trả về số đoạn không khớp");
                String[] result = new String[texts.length];
                for (int i = 0; i < result.length; i++) result[i] = out.getString(i);
                return result;
            } catch (HttpException e) {
                if ((e.code == 429 || e.code >= 500) && attempt < 2) {
                    Thread.sleep(1500L * (attempt + 1));
                    continue;
                }
                throw e;
            }
        }
    }

    // ---- HTTP ----

    private static String http(String urlStr, String contentType, String body, String apiKey) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(45000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", contentType);
            if (apiKey != null) c.setRequestProperty("x-goog-api-key", apiKey);
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) {
                os.write(bytes);
            }
            int code = c.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            String text = is == null ? "" : readAll(is);
            if (code < 200 || code >= 300) throw new HttpException(code, text);
            return text;
        } finally {
            c.disconnect();
        }
    }

    static String readAll(InputStream is) throws IOException {
        try (InputStream in = is) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
