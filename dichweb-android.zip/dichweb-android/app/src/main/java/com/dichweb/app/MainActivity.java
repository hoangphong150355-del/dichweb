package com.dichweb.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String[] CODES = {"en", "zh-CN", "vi"};
    private static final String[] LABELS = {"EN", "中文", "VI"};
    private static final String[] FULL_NAMES = {"English", "中文", "Tiếng Việt"};
    private static final int COLOR_ON = 0xFF4F46E5;
    private static final int COLOR_OFF = 0xFFE5E7EB;

    private WebView web;
    private EditText urlBox;
    private ProgressBar progress;
    private TextView status;
    private final Button[] langBtns = new Button[3];

    private volatile String currentTarget = null;
    private SharedPreferences prefs;
    private Translator translator;
    private String translateJs = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService batchPool = Executors.newFixedThreadPool(3);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vt", MODE_PRIVATE);
        translator = new Translator(prefs);
        translateJs = readAsset("translate.js");
        buildUi();
        setupWebView();

        String start = "https://www.google.com";
        Intent i = getIntent();
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getDataString() != null) {
            start = i.getDataString();
        }
        web.loadUrl(start);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getDataString() != null) {
            web.loadUrl(intent.getDataString());
        }
    }

    // ---------------- Giao diện ----------------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // Hàng 1: thanh địa chỉ
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setPadding(dp(6), dp(6), dp(6), 0);

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setHint("Nhập địa chỉ hoặc từ khóa");
        urlBox.setTextSize(15);
        urlBox.setSelectAllOnFocus(true);
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setOnEditorActionListener((v, actionId, event) -> {
            go();
            return true;
        });
        row1.addView(urlBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button goBtn = smallButton("Đi");
        goBtn.setOnClickListener(v -> go());
        row1.addView(goBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(row1, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Hàng 2: nút ngôn ngữ
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(dp(6), dp(2), dp(6), dp(4));

        for (int k = 0; k < 3; k++) {
            final String code = CODES[k];
            Button b = smallButton(LABELS[k]);
            b.setOnClickListener(v -> startTranslate(code));
            langBtns[k] = b;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row2.addView(b, lp);
        }

        Button orig = smallButton("Gốc");
        orig.setOnClickListener(v -> stopTranslate());
        LinearLayout.LayoutParams lpOrig = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lpOrig.setMargins(dp(2), 0, dp(2), 0);
        row2.addView(orig, lpOrig);

        Button settings = smallButton("⚙");
        settings.setOnClickListener(v -> showSettings());
        LinearLayout.LayoutParams lpSet = new LinearLayout.LayoutParams(dp(48), dp(42));
        lpSet.setMargins(dp(2), 0, dp(2), 0);
        row2.addView(settings, lpSet);

        root.addView(row2, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        status = new TextView(this);
        status.setTextSize(12);
        status.setTextColor(0xFF4B5563);
        status.setPadding(dp(10), dp(2), dp(10), dp(2));
        status.setVisibility(View.GONE);
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        updateButtons();
    }

    private void updateButtons() {
        for (int k = 0; k < 3; k++) {
            boolean on = CODES[k].equals(currentTarget);
            langBtns[k].setBackgroundColor(on ? COLOR_ON : COLOR_OFF);
            langBtns[k].setTextColor(on ? Color.WHITE : Color.BLACK);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.addJavascriptInterface(new Bridge(), "VT");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (!urlBox.hasFocus()) urlBox.setText(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!urlBox.hasFocus()) urlBox.setText(url);
                if (currentTarget != null) {
                    web.evaluateJavascript(translateJs, null);
                    web.evaluateJavascript("window.__vt && window.__vt.ensure(" + JSONObject.quote(currentTarget) + ")", null);
                    startPolling();
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---------------- Điều hướng ----------------

    private String normalize(String in) {
        in = in.trim();
        if (in.isEmpty()) return null;
        if (in.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return in;
        if (!in.contains(" ") && in.contains(".")) return "https://" + in;
        return "https://www.google.com/search?q=" + Uri.encode(in);
    }

    private void go() {
        String u = normalize(urlBox.getText().toString());
        if (u == null) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
        web.loadUrl(u);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        batchPool.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ---------------- Dịch ----------------

    private void startTranslate(String code) {
        currentTarget = code;
        prefs.edit().putString("target", code).apply();
        updateButtons();
        web.evaluateJavascript(translateJs, null);
        web.evaluateJavascript("window.__vt && window.__vt.start(" + JSONObject.quote(code) + ")", null);
        startPolling();
    }

    private void stopTranslate() {
        currentTarget = null;
        updateButtons();
        web.evaluateJavascript("window.__vt && window.__vt.restore()", null);
        handler.removeCallbacks(poll);
        status.setText("");
        status.setVisibility(View.GONE);
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (currentTarget == null) return;
            web.evaluateJavascript(
                    "(window.__vt ? (function(s){return (s.active?1:0)+','+s.total+','+s.done+','+s.errors;})(window.__vt.status()) : '')",
                    value -> {
                        if (currentTarget == null) return;
                        String v = value == null ? "" : value.replace("\"", "");
                        String[] p = v.split(",");
                        if (p.length == 4) {
                            int total = parseInt(p[1]), done = parseInt(p[2]), errors = parseInt(p[3]);
                            String name = nameOf(currentTarget);
                            String text;
                            if (total > done) text = "Đang dịch sang " + name + "… " + done + "/" + total;
                            else text = "Đã dịch sang " + name + (errors > 0 ? " (" + errors + " đoạn lỗi)" : "");
                            status.setText(text);
                            status.setVisibility(View.VISIBLE);
                        }
                    });
            handler.postDelayed(this, 800);
        }
    };

    private void startPolling() {
        handler.removeCallbacks(poll);
        handler.post(poll);
    }

    private static int parseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private static String nameOf(String code) {
        for (int k = 0; k < CODES.length; k++) {
            if (CODES[k].equals(code)) return FULL_NAMES[k];
        }
        return code;
    }

    /** Cầu nối để JS trong trang gọi sang Android dịch (tránh bị chặn CORS). */
    private class Bridge {
        @JavascriptInterface
        public void translate(final String id, final String textsJson, final String target) {
            if (currentTarget == null || target == null) return;
            boolean ok = false;
            for (String c : CODES) if (c.equals(target)) ok = true;
            if (!ok) return;

            batchPool.execute(() -> {
                String out = "null";
                try {
                    JSONArray in = new JSONArray(textsJson);
                    int n = Math.min(in.length(), 50);
                    String[] texts = new String[n];
                    for (int i = 0; i < n; i++) {
                        String t = in.getString(i);
                        texts[i] = t.length() > 4500 ? t.substring(0, 4500) : t;
                    }
                    String[] res = translator.translate(texts, target);
                    JSONArray arr = new JSONArray();
                    for (String r : res) arr.put(r == null ? JSONObject.NULL : r);
                    out = arr.toString();
                } catch (Exception ignored) {
                }
                final String js = "window.__vtCb(" + JSONObject.quote(id) + "," + JSONObject.quote(out) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }
    }

    // ---------------- Cài đặt ----------------

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setPadding(0, dp(12), 0, dp(2));
        return t;
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));

        box.addView(label("Công cụ dịch"));
        final Spinner engine = new Spinner(this);
        engine.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Google Translate (miễn phí)", "Gemini API (cần key)"}));
        engine.setSelection("gemini".equals(prefs.getString("engine", "google")) ? 1 : 0);
        box.addView(engine);

        box.addView(label("Gemini API key"));
        final EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setHint("Dán API key vào đây");
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(prefs.getString("apiKey", ""));
        box.addView(key);

        box.addView(label("Tên model Gemini"));
        final EditText model = new EditText(this);
        model.setSingleLine(true);
        model.setHint(Translator.DEFAULT_MODEL);
        model.setText(prefs.getString("model", Translator.DEFAULT_MODEL));
        box.addView(model);

        Button test = new Button(this);
        test.setAllCaps(false);
        test.setText("Thử kết nối Gemini");
        test.setOnClickListener(v -> {
            final String k = key.getText().toString();
            final String m = model.getText().toString();
            if (k.trim().isEmpty()) {
                toast("Hãy nhập API key trước khi thử.");
                return;
            }
            toast("Đang thử kết nối…");
            batchPool.execute(() -> {
                try {
                    String r = translator.testGemini(k, m);
                    toast("Thành công! “Hello, how are you today?” → " + r);
                } catch (Exception e) {
                    toast("Không kết nối được: " + e.getMessage());
                }
            });
        });
        box.addView(test);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("Cài đặt dịch")
                .setView(sv)
                .setPositiveButton("Lưu", (d, which) -> {
                    boolean gemini = engine.getSelectedItemPosition() == 1;
                    String k = key.getText().toString().trim();
                    String m = model.getText().toString().trim();
                    prefs.edit()
                            .putString("engine", gemini ? "gemini" : "google")
                            .putString("apiKey", k)
                            .putString("model", m.isEmpty() ? Translator.DEFAULT_MODEL : m)
                            .apply();
                    if (gemini && k.isEmpty()) {
                        toast("Chưa có API key nên app vẫn dùng Google Translate.");
                    } else {
                        toast("Đã lưu cài đặt.");
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private String readAsset(String name) {
        try (InputStream is = getAssets().open(name)) {
            return Translator.readAll(is);
        } catch (Exception e) {
            return "";
        }
    }
}
