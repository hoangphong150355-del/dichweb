// Script dịch trang: được app nạp vào WebView. Việc gọi API dịch do phần Android (đối tượng VT) thực hiện.
(function () {
  if (window.__vt) return;

  var SKIP = {
    SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, CODE: 1, PRE: 1, TEXTAREA: 1, INPUT: 1, SELECT: 1,
    OPTION: 1, SVG: 1, CANVAS: 1, KBD: 1, SAMP: 1, IFRAME: 1, MATH: 1
  };
  var BATCH = 20;
  var WORKERS = 3;

  var originals = new Map();
  var applied = new WeakMap();
  var active = false, target = null, gen = 0, total = 0, done = 0, errors = 0;
  var observer = null, pending = new Set(), timer = null;
  var cbs = {}, seq = 0;

  window.__vtCb = function (id, json) {
    var f = cbs[id];
    if (!f) return;
    delete cbs[id];
    var r = null;
    try { r = JSON.parse(json); } catch (e) { r = null; }
    f(r);
  };

  function callNative(texts, tl) {
    return new Promise(function (resolve) {
      var id = String(++seq);
      var t = setTimeout(function () {
        if (cbs[id]) { delete cbs[id]; resolve(null); }
      }, 90000);
      cbs[id] = function (r) { clearTimeout(t); resolve(r); };
      try {
        VT.translate(id, JSON.stringify(texts), tl);
      } catch (e) {
        clearTimeout(t);
        delete cbs[id];
        resolve(null);
      }
    });
  }

  function shouldSkip(node) {
    var text = node.nodeValue;
    if (!text || !/\p{L}/u.test(text)) return true;
    if (applied.get(node) === text) return true;
    for (var el = node.parentElement; el; el = el.parentElement) {
      if (SKIP[String(el.tagName).toUpperCase()]) return true;
      if (el.isContentEditable) return true;
      if (el.getAttribute("translate") === "no" || el.classList.contains("notranslate")) return true;
    }
    return false;
  }

  function collect(root) {
    var nodes = [];
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var n;
    while ((n = walker.nextNode())) {
      if (!shouldSkip(n)) nodes.push(n);
    }
    return nodes;
  }

  function sortByViewport(nodes) {
    var keyed = nodes.map(function (n) {
      var el = n.parentElement;
      var top = el ? Math.abs(el.getBoundingClientRect().top) : 1e9;
      return [top, n];
    });
    keyed.sort(function (a, b) { return a[0] - b[0]; });
    return keyed.map(function (k) { return k[1]; });
  }

  async function translateNodes(nodes) {
    if (!nodes.length) return;
    var myGen = gen;
    nodes = sortByViewport(nodes);
    total += nodes.length;

    var batches = [];
    for (var i = 0; i < nodes.length; i += BATCH) batches.push(nodes.slice(i, i + BATCH));

    var idx = 0;
    async function worker() {
      while (idx < batches.length) {
        if (myGen !== gen) return;
        var batch = batches[idx++].filter(function (n) { return n.isConnected; });
        if (!batch.length) continue;
        var texts = batch.map(function (n) { return n.nodeValue.trim(); });
        var res = await callNative(texts, target);
        if (myGen !== gen) return;
        batch.forEach(function (n, k) {
          var tr = res && res[k];
          if (tr && n.isConnected) {
            var orig = n.nodeValue;
            if (!originals.has(n)) originals.set(n, orig);
            var lead = orig.match(/^\s*/)[0];
            var trail = orig.match(/\s*$/)[0];
            var out = lead + tr + trail;
            n.nodeValue = out;
            applied.set(n, out);
          } else {
            errors++;
          }
          done++;
        });
      }
    }
    var workers = [];
    for (var w = 0; w < WORKERS; w++) workers.push(worker());
    await Promise.all(workers);
  }

  function startObserver() {
    stopObserver();
    if (!document.body) return;
    observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes.forEach(function (added) {
          if (added.nodeType === Node.TEXT_NODE) {
            if (!shouldSkip(added)) pending.add(added);
          } else if (added.nodeType === Node.ELEMENT_NODE) {
            collect(added).forEach(function (n) { pending.add(n); });
          }
        });
      });
      if (pending.size && !timer) {
        timer = setTimeout(function () {
          timer = null;
          var nodes = Array.from(pending);
          pending = new Set();
          translateNodes(nodes);
        }, 400);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (observer) observer.disconnect();
    observer = null;
    pending = new Set();
    if (timer) clearTimeout(timer);
    timer = null;
  }

  function restore() {
    gen++;
    stopObserver();
    originals.forEach(function (orig, node) {
      if (node.isConnected) node.nodeValue = orig;
    });
    originals.clear();
    active = false;
    total = done = errors = 0;
  }

  function start(lang) {
    if (active) restore();
    gen++;
    target = lang;
    active = true;
    total = done = errors = 0;
    if (!document.body) return;
    translateNodes(collect(document.body));
    startObserver();
  }

  window.__vt = {
    start: start,
    restore: restore,
    ensure: function (lang) { if (!(active && target === lang)) start(lang); },
    status: function () {
      return { active: active, target: target, total: total, done: done, errors: errors };
    }
  };
})();
